package ProductSearch;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import Methods.FlipkartMethods;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ProductSearchDef {

	WebDriver driver = FlipkartMethods.defineDriver("Chrome");
	WebDriverWait wait = new WebDriverWait(driver, 30);
	
	/** Xpaths for elements are defined here **/ 
	public String URL = "https://www.flipkart.com/";
	public String LoginWindow = "/html/body/div[2]/div/div/button";
	public String SearchBox = "//*[@id=\"container\"]/div/header/div[1]/div[2]/div/div/div[2]/form/div/div[2]/button";
	public String PriceDropDownBox = "//*[@id=\"container\"]/div/div[1]/div/div[2]/div/div[1]/div/div/div[2]/section/div[4]/div[3]/select";
	public String brandSearchBox = "//*[@id=\"container\"]/div/div[1]/div/div[2]/div/div[1]/div/div/div[4]/section/div[2]/div[1]/div[1]/input";
	public String brandSelection = "//*[@id=\"container\"]/div/div[1]/div/div[2]/div/div[1]/div/div/div[4]/section/div[2]/div[1]/div[2]/div/div/label/div[1]";
	public String sortByPrice = "//*[@id=\"container\"]/div/div[1]/div/div[2]/div/div[2]/div/div[2]/section/ul/li[3]";
	public String sortByPopularity = "//*[@id=\"container\"]/div/div[1]/div/div[2]/div/div[2]/div/div[2]/section/ul/li[2]";
	public String FilterValues = "//*[@id=\"container\"]/div/div[1]/div/div[2]/div/div[1]/div/div/section/div[2]/div[1]";
	
	/** Global elements are defined here **/
	public String brandValue;
	public String Userprice;

	@Given("^I am on flipkart landing page$")
	public void i_am_on_flipkart_landing_page() throws Throwable {
		
		driver.get(URL);
		driver.manage().window().maximize();
		try {if(driver.findElement(By.xpath(LoginWindow)).getSize()!=null) {
			driver.findElement(By.xpath(LoginWindow)).click();
		}}catch(NoSuchElementException e){}
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		}

	@When("^I enter \"([^\"]*)\" in search box$")
	public void i_enter_in_search_box(String arg1) throws Throwable {
		driver.findElement(By.name("q")).sendKeys(arg1);
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		WebElement searchBox = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(SearchBox)));
		searchBox.click();
		}
	
@When("^I set Price as \"([^\"]*)\"$")
	public void i_set_Price_as(String UserPrice) throws Throwable {
	WebElement PriceDropDown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(PriceDropDownBox)));
	Select price = new Select(PriceDropDown);
	List<WebElement> AllOptions = price.getOptions();
	List<String> TempList = new ArrayList<>();
    int SizeOfList = AllOptions.size();
    for (int m = 0; m < SizeOfList; m++) {
    	String s = AllOptions.get(m).getText();
    	TempList.add(s);}
   String SmartUserPrice =FlipkartMethods.getValue(UserPrice, TempList);
   System.out.println("DONE "+SmartUserPrice);
   price.selectByValue(SmartUserPrice);	
   Userprice= SmartUserPrice;
	}

@When("^I set brand as \"([^\"]*)\"$")
	public void i_set_brand_as(String brand) throws Throwable {
	WebElement brandElement = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(brandSearchBox)));
	brandElement.sendKeys(brand);
	WebElement brandSelect = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(brandSelection)));
	brandSelect.click();	
	brandValue =brand;
	}

	@When("^Sort with \"([^\"]*)\"$")
	public void sort_with(String Sort) throws Throwable {
		
		if(Sort.equals("Price")) {
		System.out.println("Sorting by "+Sort);
		WebElement Sorting = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(sortByPrice)));
		Sorting.click();}else {
		System.out.println("Sorting by "+Sort);
		WebElement Sorting = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(sortByPopularity)));
		Sorting.click();			
		}
	}

	@Then("^All relevent results should be displayed$")
	public void all_relevent_results_should_be_displayed() throws Throwable {
	WebElement Filter = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(FilterValues)));
		if(Filter.getText().contains(brandValue) || Filter.getText().contains(Userprice)) {
		System.out.println("PASS");
		}else System.out.println("FAIL");
	}

}
