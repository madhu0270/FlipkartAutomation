package ExistingUserSanity;

import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Methods.FlipkartMethods;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class ExistingUserSanityDef {

	
	WebDriver driver = FlipkartMethods.defineDriver("Chrome");
	WebDriverWait wait = new WebDriverWait(driver, 30);
	
	/** Xpaths for elements are defined here **/ 
	public String URL = "https://www.flipkart.com/";
	public String LoginWindow = "/html/body/div[2]/div/div/button";
	public String EnterMobileNo = "/html/body/div[2]/div/div/div/div/div[2]/div/form/div[1]/input";
	public String continueElement = "/html/body/div[2]/div/div/div/div/div[2]/div/form/div[2]/button";
	public String EnterOTP ="/html/body/div[2]/div/div/div/div/div[2]/div/form/div[2]/div[2]/input";
	public String EnterPassword ="/html/body/div[2]/div/div/div/div/div[2]/div/form/div[2]/div[3]/input";
	public String SignUpButton = "/html/body/div[2]/div/div/div/div/div[2]/div/form/div[3]/button[1]";
	public String LoginButton = "//*[@id=\"container\"]/div/header/div[1]/div[1]/div/ul/li[9]/a";
	
	/** Xpaths for elements are defined here **/ 
	
	public String PasswordElement = "/html/body/div[2]/div/div/div/div/div[2]/div/form/div[2]/input";
	public String LoginElement = "/html/body/div[2]/div/div/div/div/div[2]/div/form/div[3]/button";
	public String myAccountLink = "//*[@id=\"container\"]/div/header/div[1]/div[1]/div/ul/li[8]/a";
	public String GenderMale = "//*[@id=\\\"container\\\"]/div/div[1]/div/div/div[2]/div/div/div[1]/div[1]/form/div[3]/label[1]/div[2]/span";
	public String GenderFemale = "//*[@id=\"container\"]/div/div[1]/div/div/div[2]/div/div/div[1]/div[1]/form/div[3]/label[2]/div[2]/span";
	public String EnterUserNameElement = "/html/body/div[2]/div/div/div/div/div[2]/div/form/div[1]/input";
	public String EnterPasswordElement = "/html/body/div[2]/div/div/div/div/div[2]/div/form/div[2]/input";
	public String EmailIDElement = "/html/body/div[2]/div/div/div/div/div[2]/div/form/div[1]/input";
	public String OTPSent = "/html/body/div[2]/div/div/div/div/div[2]/div/form/div[2]/div[1]/span";
	//Link Text Resend?
	
//Check Valid/Invalid users		
	
	@Given("^I am on Flipkart Landing Page$")
	public void i_am_on_Flipkart_Landing_Page() throws Throwable {
		
		driver.get(URL);
		driver.manage().window().maximize();
		try {if(driver.findElement(By.xpath(LoginWindow)).getSize()!=null) {
			driver.findElement(By.xpath(LoginWindow)).click();
		}}catch(NoSuchElementException e){}
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@Given("^I click on LogIn button$")
	public void i_click_on_LogIn_button() throws Throwable {
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	WebElement Login = driver.findElement(By.xpath(LoginButton));
	(new WebDriverWait(driver, 30)).until(ExpectedConditions.elementToBeClickable(Login));
	Login.click();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@When("^I enter username as \"([^\"]*)\" and password as \"([^\"]*)\"$")
	public void i_enter_username_as_and_password_as(String uname, String pswd) throws Throwable {
		
		WebElement UserNameElement = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(EnterUserNameElement)));
		UserNameElement.sendKeys(uname);
		WebElement PasswordElement = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(EnterPasswordElement)));
		UserNameElement.sendKeys(pswd);	
		}

	@When("^Click on LogIn$")
	public void click_on_SignIn() throws Throwable {
	driver.findElement(By.xpath(LoginElement)).click();
	driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
	}
	
	@Then("^Login should be successful$")
	public void login_should_be_successful() throws Throwable {
	   try{if(driver.findElement(By.xpath(myAccountLink))!=null)
		   System.out.println("Login Pass");
		   else System.out.println("Login Fail");
	    	}catch (NoSuchElementException e) {
	    	System.out.println("Login Fail");
	    	}driver.quit();
	 	}
	
	@Then("^Error Message should be displayed$")
	public void error_Message_should_be_displayed() throws Throwable {
				 try{if(driver.findElement(By.xpath(LoginWindow)).getSize()!=null) {
						 System.out.println("Login Pass");
						}else System.out.println("Login Fail");
				    } catch (NoSuchElementException e) {
				    	System.out.println("Login Fail");
				    }driver.quit();
	}
	

	
	@When("^I enter Valid Email Address as \"([^\"]*)\"$")
	public void i_enter_Valid_Email_Address_as(String emailId) throws Throwable {
		WebElement EnterEmail = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(EmailIDElement)));
		EnterEmail.sendKeys(emailId);
		}
	
	@When("^I enter Invalid Email Address as \"([^\"]*)\"$")
	public void i_enter_Invalid_Email_Address_as(String emailId) throws Throwable {
		WebElement EnterEmail = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(EmailIDElement)));
		EnterEmail.sendKeys(emailId);
	}
	
	@When("^I click on Forgot option$")
	public void i_click_on_Forgot_option() throws Throwable {
		WebElement Forgot= wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Forgot?")));
		Forgot.click();
	}
	
	@Then("^OTP sent Message should be displayed$")
	public void otp_sent_Message_should_be_displayed() throws Throwable {
		WebElement OTPMsg = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(OTPSent)));
		Assert.assertTrue(OTPMsg.getText().contains("OTP sent"));
		driver.quit();
	}
	
	@Then("^OTP Sent Message should not be displayed$")
	public void otp_Sent_Message_should_not_be_displayed() throws Throwable {
		try{
			WebElement OTPMsg = driver.findElement(By.xpath(OTPSent));
		}catch(NoSuchElementException e) {
			System.out.println("PASS");
		} driver.quit();	
	}


	}
	
