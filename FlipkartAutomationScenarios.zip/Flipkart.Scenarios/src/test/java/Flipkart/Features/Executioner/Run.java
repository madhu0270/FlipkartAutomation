package Flipkart.Features.Executioner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class) 
@CucumberOptions(features= {"Features/NewUserSignUp.feature"}, 	/*Enter the feature you want to execute*/
glue= {"Flipkart/Features/StepDefinitions"},					/*Enter the respective Step Def File*/
plugin= {"html:target/html-report"})
//tags = {"~@md"})
public class Run {
}