package NewUserSignUp;

import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Methods.FlipkartMethods;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class NewUserSignUpDef {

	WebDriver driver = FlipkartMethods.defineDriver("Chrome");
	WebDriverWait wait = new WebDriverWait(driver, 30);
	
	/** Xpaths for elements are defined here **/ 
	private String URL = "https://www.flipkart.com/";
	private String LoginWindow = "/html/body/div[2]/div/div/button";
	private String EnterMobileNo = "/html/body/div[2]/div/div/div/div/div[2]/div/form/div[1]/input";
	private String continueElement = "/html/body/div[2]/div/div/div/div/div[2]/div/form/div[2]/button";
	private String EnterOTP ="/html/body/div[2]/div/div/div/div/div[2]/div/form/div[2]/div[2]/input";
	private String EnterPassword ="/html/body/div[2]/div/div/div/div/div[2]/div/form/div[2]/div[3]/input";
	private String SignUpButton = "/html/body/div[2]/div/div/div/div/div[2]/div/form/div[3]/button[1]";
	private String myAccountLink = "//*[@id=\"container\"]/div/header/div[1]/div[1]/div/ul/li[8]/a";
	
//Check Valid/Invalid users		
	
	@Given("^I am on Flipkart Landing Page$")
	public void i_am_on_Flipkart_Landing_Page() throws Throwable {
		driver.get(URL);
		driver.manage().window().maximize();
		try {if(driver.findElement(By.xpath(LoginWindow)).getSize()!=null) {
			driver.findElement(By.xpath(LoginWindow)).click();
		}}catch(NoSuchElementException e){}
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@Given("^I click on Sign Up button$")
	public void i_click_on_Sign_Up_button() throws Throwable {	
		WebElement SignUp = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Signup")));
	(new WebDriverWait(driver, 30)).until(ExpectedConditions
	.elementToBeClickable(SignUp));
	SignUp.click();
	}

	@When("^I enter new Mobile Number as \"([^\"]*)\"$")
	public void i_enter_existing(String NewMobileNo) throws Throwable {
	WebElement MobileNoElement = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(EnterMobileNo)));
	MobileNoElement.sendKeys(NewMobileNo);
   	}

	@When("^click on continue$")
	public void click_on_continue() throws Throwable {
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath(continueElement))).click();
	}

	@Then("^OTP sent message should be displayed$")
	public void message_should_be_displayed() throws Throwable {
	System.out.println("OTP Sent");
	driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
	}
	
	@When("^I enter OTP$")
	public void i_enter_OTP() throws Throwable {
		String OTP =   JOptionPane.showInputDialog("Please input OTP you've received on your mobile number");
		WebElement OTPelement = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(EnterOTP)));
		OTPelement.sendKeys(OTP);
		}
	
	@When("^set Password \"([^\"]*)\"$")
	public void set_Password(String Password) throws Throwable {
		WebElement SetPassword = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(EnterPassword)));
		SetPassword.sendKeys(Password);
	}

	@When("^Click on SignUp$")
	public void click_on_SignUp() throws Throwable {
		WebElement SignUpButtonElement = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(SignUpButton)));
		SignUpButtonElement.click();
	}
	
	@Then("^My Account should be displayed$")
	public void my_Account_should_be_displayed() throws Throwable {
		WebElement MyAccount = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(myAccountLink)));
		Assert.assertTrue(MyAccount!= null);
	}
	
}
