package ExistingUser;

import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Methods.FlipkartMethods;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ExistingUserDef {
	
	WebDriver driver = FlipkartMethods.defineDriver("Chrome");
	WebDriverWait wait = new WebDriverWait(driver, 30);
	
	/** Xpaths for elements are defined here **/ 
	public String URL = "https://www.flipkart.com/";
	public String LoginWindow = "/html/body/div[2]/div/div/button";
	public String EnterMobileNo = "/html/body/div[2]/div/div/div/div/div[2]/div/form/div[1]/input";
	public String continueElement = "/html/body/div[2]/div/div/div/div/div[2]/div/form/div[2]/button";
	public String EnterOTP ="/html/body/div[2]/div/div/div/div/div[2]/div/form/div[2]/div[2]/input";
	public String EnterPassword ="/html/body/div[2]/div/div/div/div/div[2]/div/form/div[2]/div[3]/input";
	public String SignUpButton = "/html/body/div[2]/div/div/div/div/div[2]/div/form/div[3]/button[1]";
	public String LoginButton = "//*[@id=\"container\"]/div/header/div[1]/div[1]/div/ul/li[9]/a";
	public String PasswordElement = "/html/body/div[2]/div/div/div/div/div[2]/div/form/div[2]/input";
	public String LoginElement = "/html/body/div[2]/div/div/div/div/div[2]/div/form/div[3]/button";
	public String myAccountLink = "//*[@id=\"container\"]/div/header/div[1]/div[1]/div/ul/li[8]/a";
	public String GenderMale = "//*[@id=\\\"container\\\"]/div/div[1]/div/div/div[2]/div/div/div[1]/div[1]/form/div[3]/label[1]/div[2]/span";
	public String GenderFemale = "//*[@id=\"container\"]/div/div[1]/div/div/div[2]/div/div/div[1]/div[1]/form/div[3]/label[2]/div[2]/span";


	
/*Background for Scenario*/
	
	@Given("^I am on Flipkart Landing Page$")
	public void i_am_on_Flipkart_Landing_Page() throws Throwable {
		
		driver.get(URL);
		driver.manage().window().maximize();
		try {if(driver.findElement(By.xpath(LoginWindow)).getSize()!=null) {
			driver.findElement(By.xpath(LoginWindow)).click();
		}}catch(NoSuchElementException e){}
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@Given("^I click on LogIn button$")
	public void i_click_on_LogIn_button() throws Throwable {
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	WebElement Login = driver.findElement(By.xpath(LoginButton));
	(new WebDriverWait(driver, 30)).until(ExpectedConditions.elementToBeClickable(Login));
	Login.click();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@When("^I enter Mobile Number \"([^\"]*)\"$")
	public void i_enter_Mobile_Number(String ExistingMobileNo) throws Throwable {
	driver.findElement(By.xpath(EnterMobileNo)).sendKeys(ExistingMobileNo);
	driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);										
	}

	@When("^I Password \"([^\"]*)\"$")
	public void i_Password(String Password) throws Throwable {
	driver.findElement(By.xpath(PasswordElement)).sendKeys(Password);
	driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);		
	}

	@When("^Click on LogIn$")
	public void click_on_SignIn() throws Throwable {
	driver.findElement(By.xpath(LoginElement)).click();
	driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
	}
	
	/**THIS METHOD NEEDS MODIFICATION**/
	
	@Then("^My Account should be displayed$")
	public void my_Account_should_be_displayed() throws Throwable {
	WebElement MyAccount = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(myAccountLink)));
	Assert.assertTrue(MyAccount!= null);
	}

/*Scenario: Update Personal Information*/
	
	@Given("^I am on Account Page$")
	public void i_am_on_Account_Page() throws Throwable {
		//Click Hi madhu
		WebElement MyAccount = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(myAccountLink)));
		MyAccount.click();
	}
	
	@When("^I click on edit personal information option$")
	public void i_click_on_edit_personal_information_option() throws Throwable {
	    driver.findElement(By.className("_1x4IU1")).click();
	    Thread.sleep(1000);
	}

	@When("^I enter \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_enter_and(String FirstName, String LastName) throws Throwable {
		
		WebElement FirstNameElement = wait.until(ExpectedConditions.elementToBeClickable(By.name("firstName")));
		FirstNameElement.clear();
		FirstNameElement.sendKeys(FirstName);
		WebElement LastNameElement = wait.until(ExpectedConditions.elementToBeClickable(By.name("lastName")));
		LastNameElement.clear();
		LastNameElement.sendKeys(LastName);
		 }

	@When("^select \"([^\"]*)\"$")
	public void select(String Gender) throws Throwable {
	 	try {
	 	JavascriptExecutor js = (JavascriptExecutor)driver; 
	 	if(Gender.equalsIgnoreCase("Male")) {
	 	WebElement GenderElement = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(GenderMale)));
	 	js.executeScript("arguments[0].click();", GenderElement);
	 	}else {
	 	WebElement GenderElement = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(GenderFemale)));
		js.executeScript("arguments[0].click();", GenderElement);
	 	}}catch(TimeoutException e){
	 		driver.findElement(By.id(Gender)).click();}
	}

	@When("^Click save$")
	public void click_save() throws Throwable {
		WebElement SaveElement = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"container\"]/div/div[1]/div/div/div[2]/div/div/div[1]/div[1]/form/div[1]/button")));
		SaveElement.click();
		}
	
	@Then("^Personal Information Option should be disabled$")
	public void personal_Information_Option_should_be_disabled() throws Throwable {
		if(!driver.findElement(By.name("firstName")).isEnabled())
			System.out.println("Disabled : So PASS");
		else System.out.println("Failed");
	}

	@When("^I click edit email Option$")
	public void i_click_edit_email_Option() throws Throwable {
		WebElement EditEmailElement = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"container\"]/div/div[1]/div/div/div[2]/div/div/div[1]/div[2]/div[1]/div/div/a[1]")));
		EditEmailElement.click();
	}

	@When("^Enter \"([^\"]*)\" and Click save$")
	public void enter_and_Click_save(String email) throws Throwable {
		WebElement EnterEmailElement = wait.until(ExpectedConditions.elementToBeClickable(By.name("email")));
		EnterEmailElement.sendKeys(email);
		WebElement ClickSaveElement = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"container\"]/div/div[1]/div/div/div[2]/div/div/div[1]/div[2]/div[1]/div/form/div/button")));
		ClickSaveElement.click();
		}

	@Then("^Email Option should be disabled$")
	public void email_Option_should_be_disabled() throws Throwable {
		Thread.sleep(4000);
		if(!driver.findElement(By.name("email")).isEnabled())
    	System.out.println("Disabled: Pass");
    else System.out.println("Failed");
	}
	
	
}
