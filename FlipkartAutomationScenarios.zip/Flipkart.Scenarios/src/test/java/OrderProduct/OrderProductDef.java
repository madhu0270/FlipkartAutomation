package OrderProduct;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import Methods.FlipkartMethods;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class OrderProductDef {

	WebDriver driver = FlipkartMethods.defineDriver("Chrome");
	WebDriverWait wait = new WebDriverWait(driver, 30);
	
	/** Xpaths for elements are defined here **/ 
	public String URL = "https://www.flipkart.com/";
	public String LoginWindow = "/html/body/div[2]/div/div/button";
	public String SearchBox = "//*[@id=\"container\"]/div/header/div[1]/div[2]/div/div/div[2]/form/div/div[2]/button";
	public String ProductName1 = "//*[@id=\"container\"]/div/div[1]/div/div[2]/div/div[2]/div/div[3]/div[1]/div[1]/div[1]/div/a[2]";
	public String ProductName2 = "//*[@id=\"container\"]/div/div[1]/div/div[2]/div/div[2]/div/div[3]/div[1]/div/div[1]/div/a/div[3]/div[1]/div[1]";
	public String buyMe1 = "//*[@id=\"container\"]/div/div[1]/div/div/div/div[1]/div/div[1]/div[2]/ul/li[2]/form/button";
	public String buyMe2 = "//*[@id=\"container\"]/div/div[1]/div/div/div/div[1]/div/div[1]/div[2]/ul/li/button";
	public String LoginSignUpText = "//*[@id=\"container\"]/div/div[1]/div/div/div[1]/div[1]/div/h3/span[2]";
	public String UName = "input[type='text']";
	public String Pass = "//*[@id=\"container\"]/div/div[1]/div/div/div[1]/div[1]/div/div/div/div/div[1]/div/form/div[2]/input";
	public String Sbmt = "button[type='submit']";
	public String ChangeUser = "//*[@id=\"container\"]/div/div[1]/div/div/div[1]/div[1]/div/div/button";
	public String ChangeAddress = "//*[@id=\"container\"]/div/div[1]/div/div/div[1]/div[2]/div/div/button";
	public String OrderSummary = "//*[@id=\"container\"]/div/div[1]/div/div/div[1]/div[3]/div/h3/span[2]";
	public String ClickContinue = "//*[@id=\"to-payment\"]/button";
	public String PaymentOptions = "//*[@id=\"container\"]/div/div[1]/div/div/div[1]/div[4]/h3/span[2]";
	public String NetBanking = "//*[@id=\"container\"]/div/div[1]/div/div/div[1]/div[4]/div/div/div/div[3]/div/label[3]/div[1]";
	public String ICICI = "//*[@id=\"container\"]/div/div[1]/div/div/div[1]/div[4]/div/div/div/div[3]/div/label[3]/div[2]/div/div/div[1]/label[2]/div[1]";
	public String ToPayment = "//*[@id=\"container\"]/div/div[1]/div/div/div[1]/div[4]/div/div/div/div[3]/div/label[3]/div[2]/div/div/button";
	

	@Given("^I am on flipkart landing page$")
	public void i_am_on_flipkart_landing_page() throws Throwable {
		
		driver.get(URL);
		driver.manage().window().maximize();
		try {if(driver.findElement(By.xpath(LoginWindow)).getSize()!=null) {
			driver.findElement(By.xpath(LoginWindow)).click();
		}}catch(NoSuchElementException e){}
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("Going to search box");
		}

	
	@When("^I click on product name$")
	public void i_click_on_product_name() throws Throwable {
		try {
		WebElement searchResult = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(ProductName1)));
		searchResult.click();
		}catch(TimeoutException e) {
			System.out.println("Caught Exception");
			WebElement searchResult = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(ProductName2)));
			searchResult.click();	
		}
			}
	
	@When("^I enter \"([^\"]*)\" in search box$")
	public void i_enter_in_search_box(String arg1) throws Throwable {
		System.out.println("In searchbox method");
		driver.findElement(By.name("q")).sendKeys(arg1);
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		WebElement searchBox = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(SearchBox)));
		searchBox.click();
		}
	
	@Then("^Product Page Should open$")
	public void product_Page_Should_open() throws Throwable {
		Set <String> allTabs = driver.getWindowHandles();
		String newTab = null;
		Iterator<String> itr = allTabs.iterator();
		while(itr.hasNext()){
	     newTab = (String) itr.next();
	    }
	    driver.switchTo().window(newTab);
	    System.out.println("Item Page Title: "+driver.getTitle());
	    }

	@When("^I Clickon Buy now$")
	public void i_Clickon_Buy_now() throws Throwable {
		try {
			Thread.sleep(10000);
			System.out.println("In Try");
			Actions actions = new Actions(driver);
			WebElement buy = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(buyMe1)));
			actions.moveToElement(buy).click().build().perform();			
			}catch(TimeoutException e) {
			Thread.sleep(10000);
			System.out.println("Cathed TimeoutException ");
			JavascriptExecutor js1 = (JavascriptExecutor)driver; 
			js1.executeScript("arguments[0].click();", driver.findElement(By.xpath(buyMe1))); 
			}
		}

	@Then("^I should be asked too Login or SignUp$")
	public void i_should_be_asked_too_Login_or_SignUp() throws Throwable {
	    wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(LoginSignUpText)));
		String LoginSignUp = driver.findElement(By.xpath(LoginSignUpText)).getText();
	    Assert.assertEquals("LOGIN OR SIGNUP", LoginSignUp);
	    }
	
	@When("^I enter \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_enter_and(String username, String password) throws Throwable {
		WebElement Username = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(UName)));
		Username.sendKeys(username);
		WebElement Submit = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Sbmt)));
		Submit.click();
		WebElement Password = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Pass)));
	    Password.sendKeys(password);
	    WebElement SubmitAgain = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Sbmt)));
	    SubmitAgain.click();
	    }

	/*Method Checks for [Change] button next to Login Option on the page]*/
	@Then("^Login should be successful$")
	public void login_should_be_successful() throws Throwable {
		WebElement Number = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ChangeUser)));
		Assert.assertTrue(Number.isDisplayed());
	}
	
	/*Method Checks for [Change] button next to Deliver Here Option on the page]*/
	@Then("^default address should be displayed$")
	public void default_address_should_be_displayed() throws Throwable {
		//delivery Address
		WebElement Deliver = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ChangeAddress)));
		Assert.assertTrue(Deliver.isDisplayed());
	}

	@Then("^Order summary should be displayed$")
	public void order_summary_should_be_displayed() throws Throwable {
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(OrderSummary)));
		String Summary = driver.findElement(By.xpath(OrderSummary)).getText();
		Assert.assertEquals("ORDER SUMMARY", Summary);
		}

	@When("^I click on Continue$")
	public void i_click_on_Continue() throws Throwable {
			WebElement Continue = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(ClickContinue)));
			Continue.click();
	}

	@Then("^Payment option should be displayed$")
	public void payment_option_should_be_displayed() throws Throwable {
	    String Payment = driver.findElement(By.xpath(PaymentOptions)).getText();
		Assert.assertEquals("PAYMENT OPTIONS", Payment);
	}

	@When("^I click on \"([^\"]*)\" and select \"([^\"]*)\" and click Pay button$")
	public void i_click_on_and_select_and_click_Pay_button(String PaymentMode, String Bank) throws Throwable {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(10000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(NetBanking)));
		WebElement Pay = driver.findElement(By.xpath(NetBanking));
		JavascriptExecutor js1 = (JavascriptExecutor)driver; 
		js1.executeScript("arguments[0].click();", Pay); 
		Thread.sleep(10000);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebElement bank = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(ICICI)));
		js1.executeScript("arguments[0].click();", bank);
		Thread.sleep(9000);
		WebElement ToBankPage = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(ToPayment)));
		js1.executeScript("arguments[0].click();", ToBankPage);
		}

	@Then("^I should be navigated to ICICI Bank$")
	public void i_should_be_navigated_to_ICICI_Bank() throws Throwable {
	Assert.assertTrue(driver.getTitle().contains("Secure Payment"));
	System.out.println("Last Test Pass");
	driver.quit();
	}

	
}
