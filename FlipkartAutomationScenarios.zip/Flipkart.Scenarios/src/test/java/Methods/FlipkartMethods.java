package Methods;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class FlipkartMethods {

	public static String WorkSpaceLocation  ="D:\\MyWork\\Flipkart\\Flipkart.Scenarios\\";

	
	public static WebDriver defineDriver(String browser) {
		WebDriver driver =null;
		if(browser.equalsIgnoreCase("Chrome")) {
		System.setProperty("webdriver.chrome.driver", WorkSpaceLocation+"Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		return driver;
		}else if(browser.equalsIgnoreCase("Firefox")) {
		System.setProperty("webdriver.gecko.driver", WorkSpaceLocation+"Drivers\\geckodriver.exe");
		driver = new FirefoxDriver();
		return driver;
		}
		return driver;		
		}
	
	/**Didn't use this function in any method**/
	public void Login(WebDriver driver, String ExistingMobileNo,String Password) {
			/*OPEN FLIPKART*/
			defineDriver("Chrome");
			driver.get("https://www.flipkart.com/");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			/*CLICK LOGIN*/
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			WebElement Login = driver.findElement(By.xpath("//*[@id=\"container\"]/div/header/div[1]/div[1]/div/ul/li[9]/a"));
			(new WebDriverWait(driver, 30)).until(ExpectedConditions.elementToBeClickable(Login));
			Login.click();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			/*ENTER MOBILE NO*/
			driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[1]/input")).sendKeys(ExistingMobileNo);
			driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);										
			driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[2]/input")).sendKeys(Password);
			/*CLICK LOGIN BUTTON*/
			driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);		
			driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[3]/button")).click();
			driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			System.out.println("You are now Logged in");		
		}

	/**The function is used for getting Price dropdown value**/
	public static String getValue(String UserValue, List<String> TempList) {
		
		List<String> MyTempList = new ArrayList<>();
	    int SizeOfList = TempList.size();
	   
	  //Add All Elements after trimming
	    for (int j = 0; j < SizeOfList-1; j++) {
	    	String s = TempList.get(j).substring(1);
	    	MyTempList.add(s);
	      	}
	    String GetLastElelment = TempList.get(SizeOfList-1);
	    String LastElement = GetLastElelment.substring(0, GetLastElelment.length()-1 );
	    //String LastElement = TempList.get(SizeOfList-1);
	    LastElement = LastElement.substring(1);
	    int  UservalInt = Integer.parseInt(UserValue);
	    int LastElementInt = Integer.parseInt(LastElement);
	    if(UservalInt > LastElementInt) {
	    	return "Max";
	    }else {
		
		
	    int FinalVal = 0;
	    for(int i = 0; i < MyTempList.size(); i++) {
	     int valueinList = Integer.parseInt(MyTempList.get(i));
	     if(UservalInt<valueinList) {
	     FinalVal = Integer.parseInt(MyTempList.get(i-1));
	     break;}    
	    }
	    if(FinalVal ==0)
	    FinalVal = Integer.parseInt(MyTempList.get(MyTempList.size()-1));
	    String FinalValString = Integer.toString(FinalVal);
	    return FinalValString;
	    }
		
	}

	
	
	
	
	
	
	
}
